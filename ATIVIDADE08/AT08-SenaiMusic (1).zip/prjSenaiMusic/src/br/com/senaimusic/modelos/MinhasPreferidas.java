package br.com.senaimusic.modelos;

public class MinhasPreferidas {

	//metodos
	public void incluir(Audio audio) {
		if(audio.getClassificacao() >=9) {
			System.out.println("Incrivel");
		}
		else {
			System.out.println("Meio paia");
		}
	}
	
	
}
