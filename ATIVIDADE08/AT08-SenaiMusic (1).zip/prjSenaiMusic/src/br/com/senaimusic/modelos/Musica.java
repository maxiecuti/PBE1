package br.com.senaimusic.modelos;

public class Musica extends Audio {

//Atributos
private String album;
private String cantor;
private String genero;

//Getters and Setters
public String getAlbum() {
	return this.album;
}
public void setAlbum(String album) {
	this.album = album;
}
public String getCantor() {
	return this.cantor;
}
public void setCantor (String cantor) {
	this.cantor = cantor;
}
public String getGenero() {
	return this.genero;
}
public void setGenro(String genero) {
	this.genero = genero;
}

@Override
public double getClassificacao() {
	if(this.getTotalReproducoes() > 2000) {
		return 10;
	}
	else {
		return 7;
	}
}




}
