package br.com.bibiotecasenai.principal;

import br.com.bibliotecasenai.usuarios.Bibliotecario;
import br.com.bibliotecasenai.usuarios.Usuario;
import br.com.bibliotecasenai.itens.*;

public class Aplicacao {

	public static void main(String[] args) {
		Usuario usuario01 = new Usuario();
		usuario01.setNome("Lucas");
		usuario01.setcpf(409);
		usuario01.setIdade (14);
		
		Usuario usuario02 = new Usuario();
		usuario02.setNome("Leandro");
		usuario02.setcpf(508);
		usuario02.setIdade(19);
		
		Bibliotecario bibliotecario01 = new Bibliotecario();
		bibliotecario01.setNome("Vedilson");
		bibliotecario01.setMatricula("Letras");
		
		//Emprestimos e devoluções
		for(int i = 0, i < 10, i++) {
			u
		}
		
	}

}
