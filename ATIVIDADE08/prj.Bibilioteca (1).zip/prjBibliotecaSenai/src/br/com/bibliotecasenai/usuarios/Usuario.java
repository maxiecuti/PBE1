package br.com.bibliotecasenai.usuarios;

public class Usuario extends Pessoa {

	//atributos
	private int cpf;
	private int livrosEmprestados;
	
	//Getters e Setters
	public void setcpf(int cpf) {
		this.cpf = cpf;
	}
	public int getcpf() {
		return this.cpf;
	}
	public void setlivrosEmprestados (int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}
	public int getlivrosEmprestados () {
		return this.livrosEmprestados;
	}
}
