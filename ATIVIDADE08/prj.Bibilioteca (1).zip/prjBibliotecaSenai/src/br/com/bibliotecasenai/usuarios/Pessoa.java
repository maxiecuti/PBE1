package br.com.bibliotecasenai.usuarios;

public class Pessoa {

	//atributos
	private String Nome;
	private int Idade;
	
	//construtores 
	public Pessoa() {
		
	}
	public Pessoa(String Nome) {
		this.Nome = Nome;
		this.Idade = 0;
	}
	
	//Getters and Setters
	public void setNome(String Nome) {
		this.Nome = Nome;
	}
	public String getNome() {
		return this.Nome;
	}
	public void setIdade(int Idade) {
		this.Idade = Idade;
	}
	public int getIdade() {
		return this.Idade;
	}

}
