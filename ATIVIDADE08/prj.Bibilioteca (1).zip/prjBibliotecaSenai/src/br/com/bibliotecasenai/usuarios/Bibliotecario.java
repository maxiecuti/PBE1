package br.com.bibliotecasenai.usuarios;

public class Bibliotecario extends Pessoa{

	//atributos
	private String matricula;
	
	//gettes e setters
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getMatricula() {
		return this.matricula;
	}
	
	
	
	//metodos 
	public void realizarEmprestimo() {
		System.out.println(this.getNome() + " Realizou um emprestimo");
	}
	public void realizardevolucao() {
		System.out.println(this.getNome() + " Devolvel o livro");
	}
}
