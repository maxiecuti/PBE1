package br.com.bibliotecasenai.itens;

public class Livro {

	//atributos
	private String titulo;
	private String autor;
	private int isbn;
	private boolean disponivel;
	
	//getters e setters
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getTitulo() {
		return this.titulo;
	}
	public void setAutor (String autor) {
		this.autor = autor;
	}
	public String getAutor () {
		return this.autor;
	}
	public void setisbn (int isbn) {
		this.isbn = isbn;
	}
	public int getisbn () {
		return this.isbn;
	}
	public void setDisponivel (boolean disponivel) {
		this.disponivel = disponivel;
	}
	public boolean getDisponivel () {
		return this.disponivel;
	}
}
