package br.com.bibliotecasenai.itens;

import br.com.bibliotecasenai.usuarios.Usuario;

public class Emprestimo {

	//atributos
	private int numeroEmprestimo;
	
	//metodos 
	public void emprestarLivro (Livro livro, Usuario usuario) {
		usuario.setlivrosEmprestados(usuario.getlivrosEmprestados() +1);
	}
	public void devolverLivro (Livro livro, Usuario usuario) {
		usuario.setlivrosEmprestados(usuario.getlivrosEmprestados() -1);
	}
}
