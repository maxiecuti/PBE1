package br.com.bibiotecasenai.principal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.bibiotecasenai.principal.entities.Editora;
import br.com.bibiotecasenai.principal.repository.EditoraRepository;

@Service
public class EditoraService {
	
    @Autowired
    private EditoraRepository editoraRepository;
    
    public List<Editora> getAllEditora() {
        return editoraRepository.findAll();
    }

	public Editora saveEditora(Editora editora) {
		return editoraRepository.save(editora);
	}

	public Editora getEditoraById(Long id_editora) {
		return editoraRepository.findById(id_editora).orElse(null);
	}

	public void deleteEditora(Long id_editora) {
		editoraRepository.deleteById(id_editora);
	}

}
