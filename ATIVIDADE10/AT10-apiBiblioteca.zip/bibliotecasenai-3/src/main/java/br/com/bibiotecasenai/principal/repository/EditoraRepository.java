package br.com.bibiotecasenai.principal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bibiotecasenai.principal.entities.Editora;

public interface EditoraRepository extends JpaRepository<Editora, Long>{

}
