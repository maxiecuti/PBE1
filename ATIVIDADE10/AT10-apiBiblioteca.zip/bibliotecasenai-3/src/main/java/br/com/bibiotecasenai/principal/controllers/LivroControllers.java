package br.com.bibiotecasenai.principal.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.bibiotecasenai.principal.entities.Livro;
import br.com.bibiotecasenai.principal.service.LivroService;

@RestController
@RequestMapping("/livro")
public class LivroControllers {

	private LivroService livroService = new LivroService();

	@PostMapping
	public Livro createLivro(@RequestBody Livro livro) {
		return livroService.savelivro(livro);
	}

	@GetMapping
	public List<Livro> getAllLivro() {
		return livroService.getAllLivro();
	}

	@GetMapping("/{id}")
	public Livro getLivro(@PathVariable Long id_livro) {
		return livroService.getLivroById(id_livro);
	}

	@DeleteMapping("/{id}")
	public void deleteLivro(@PathVariable Long id_livro) {
		livroService.deleteLivro(id_livro);
	}

}
