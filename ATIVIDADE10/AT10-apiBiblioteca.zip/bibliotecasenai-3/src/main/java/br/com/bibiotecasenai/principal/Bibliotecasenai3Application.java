package br.com.bibiotecasenai.principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bibliotecasenai3Application {

	public static void main(String[] args) {
		SpringApplication.run(Bibliotecasenai3Application.class, args);
	}

}
