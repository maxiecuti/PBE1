package br.com.bibiotecasenai.principal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bibiotecasenai.principal.entities.Livro;

public interface LivroRepository extends JpaRepository<Livro, Long>{

}
