package prjPokemonV2;

public class Pokemon {
	
	//Atributo
	String nome;
	String elemento;
	int nivel;
	int defesa;
	int hp;
	
	//Construtores
	public Pokemon() {
	}
		public Pokemon(String Nome, String Elemento, int Nivel, int Defesa, int Hp) {
	    this.nome = Nome;
		this.elemento = Elemento;
		this.nivel = Nivel;
		this.defesa = Defesa;
		this.hp = Hp;
	}
		//Getter e Setter
		public String getNome() {
		return nome;
		}
		public void setNome(String nome) {
		this.nome = nome;
		}
		public String getElemento() {
		return elemento;
		}
		public void setElemento(String elemento) {
		this.elemento = elemento;
		}
		public int getNivel() {
		return nivel;
		}
		public void setNivel(int nivel) {
		this.nivel = nivel;
		}
		public int getDefesa() {
		return defesa;
		}
		public void setDefesa(int defesa) {
		this.defesa = defesa;
		}
		public int getHp() {
		return hp;
		}
		public void setHp(int hp) {
		this.hp = hp;
		}
				

		
		//Metodos
		public void Atacar() {
			System.out.println(this.nome + "está atacando");
		}
		public void Evoluir() {
			if(this.nivel < 3){
			this.nivel = nivel + 1;	
			System.out.println(this.nome + " evoluiu!");
			}
			else {
			System.out.println(this.nome + " não tem como evoluir");
				
			}
		}
		
		public void Info() {
			 System.out.println("Nome: " + this.nome);
			 System.out.println("Elemento: " + this.elemento);
			 System.out.println("Nivel: " + this.nivel);
			 System.out.println("Defesa: " + this.defesa);
			 System.out.println("Hp: " + this.hp);
			
		}	
}


