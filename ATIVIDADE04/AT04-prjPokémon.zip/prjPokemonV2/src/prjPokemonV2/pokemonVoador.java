package prjPokemonV2;

public class pokemonVoador extends Pokemon{
	
	//Metodos
		public void Voar() {
			System.out.println(this.nome + " está voando");
		}
		
		@Override
		public void Atacar () {
			System.out.println(this.nome + " ataque de asa");
		}
		@Override
		public void Evoluir () {
			System.out.println(this.nome + " evoluiu!");
		}
		


}
