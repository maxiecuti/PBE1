package prjPokemonV2;

public class pokemonFogo extends Pokemon{
	
	//Metodos
	    @Override
        public void Atacar() {
			System.out.println(this.nome + " atacou bola de fogo");
			System.out.println(this.nome + " atacou esplosão de fogo");
			System.out.println(this.nome + " atacou lança chamas");
		}
		@Override 
		public void Evoluir () {
			System.out.println(this.nome + " evoluiu!");
		}


}
