package prjPokemonV2;

public class pokemonAgua extends Pokemon {
	
	//Metodos
	public void surfar() {
		System.out.println(this.nome + " está surfando");
	}
	
	@Override
	public void Atacar () {
		System.out.println(this.nome + " está atacando canhão de água");
	}
	@Override
	public void Evoluir () {
		System.out.println(this.nome + " evoluiu!");
	}
	

}
