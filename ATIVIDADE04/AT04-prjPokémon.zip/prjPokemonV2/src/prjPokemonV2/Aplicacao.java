package prjPokemonV2;

public class Aplicacao {
	
	public static void main(String[] args) {
	
	pokemonAgua piplup = new pokemonAgua();
	 
	piplup.setNome ("Piplup ");
	piplup.setElemento ("Água");
	piplup.setNivel (1);
	piplup.setDefesa (53);
	piplup.setHp(36);
	
	pokemonAgua squirtle = new pokemonAgua();
	
	squirtle.setNome ("Squirtle ");
	squirtle.setElemento ("Água");
	squirtle.setNivel(1);
	squirtle.setDefesa (65);
	squirtle.setHp(44);
	
	pokemonVoador ninjask = new pokemonVoador();
	
	ninjask.setNome("Ninjask ");
	ninjask.setElemento("Voador/Inseto");
	ninjask.setNivel(2);
	ninjask.setDefesa(45);
	ninjask.setHp(61);
	
	pokemonVoador crobat = new pokemonVoador();
	
	crobat.setNome("Crobat ");
	crobat.setElemento("Voador/Venenoso");
	crobat.setNivel(3);
	crobat.setDefesa(80);
	crobat.setHp(85);
	
	pokemonFogo flareon = new pokemonFogo();
	
	flareon.setNome("Flareon ");
	flareon.setElemento("Fogo");
	flareon.setNivel(2);
	flareon.setDefesa(60);
	flareon.setHp(65);
	
	pokemonFogo pansear = new pokemonFogo();
	
	pansear.setNome("Pansear ");
	pansear.setElemento("Fogo");
	pansear.setNivel(1);
	pansear.setDefesa(48);
	pansear.setHp(50);
	
	piplup.Info();
	piplup.Atacar();
	piplup.Evoluir();

	squirtle.Info();
	squirtle.Atacar();
	squirtle.Evoluir();
	
	ninjask.Info();
	ninjask.Atacar();
	ninjask.Evoluir();
	
	crobat.Info();
	crobat.Atacar();
	crobat.Evoluir();
	
	flareon.Info();
	flareon.Atacar();
	flareon.Evoluir();
	
	pansear.Info();
	pansear.Atacar();
	pansear.Evoluir();
	
	}

	private static void surfar() {
		// TODO Auto-generated method stub
		
	}

}
