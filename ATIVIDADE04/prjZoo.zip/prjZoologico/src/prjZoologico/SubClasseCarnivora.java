package prjZoologico;

public class SubClasseCarnivora extends ClasseAnimais{
	 
	//Metodos
	public void metodoCacar() {
		System.out.println(this.atributoNome + " está caçando");
		
	}
	
	@Override
	public void metodoEmitirSom() {
		//katy perry song
		System.out.println("ROAR");
	}

} 


