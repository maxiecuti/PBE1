package prjZoologico;

public class subClasseReptil extends ClasseAnimais {
	
	//metodos
	public void trocarPele() {
	System.out.println(this.atributoNome + "está trocando de pele");
	}
	
	public void metodoRastejar() {
	System.out.println(this.atributoNome + "está rastejando");
	}
	
	@Override
	public void metodoEmitirSom() {
    System.out.println("SsssssSSs");
	}
}
