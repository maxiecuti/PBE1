package prjZoologico;

public class Aplicacao {
	
public static void main(String[] args) {
		
		ClasseAnimais elefante = new ClasseAnimais();
		
		elefante.setNome("Dumbo");
		elefante.setPeso(170);
		
		elefante.atributoNome = "Dumbo";
		elefante.atributoRaca = "Africano";
		elefante.atributoSexo = "Macho";
		elefante.atributoPeso = 170;
		
		ClasseAnimais girafa = new ClasseAnimais("Melman", "Masai", "Macho", 750);
		
        SubClasseCarnivora leao = new SubClasseCarnivora();
		
		elefante.atributoNome = "Nala";
		elefante.atributoRaca = "Africana";
		elefante.atributoSexo = "Fêmea";
		elefante.atributoPeso = 130;
		
		elefante.exibirInfo();
		
		elefante.metodoComer();
		
		elefante.exibirInfo();
		
		elefante.metodoEmitirSom();
		
		elefante.exibirInfo();
		
		girafa.exibirInfo();
		
		girafa.metodoComer();
		
		girafa.exibirInfo();
		
		girafa.metodoEmitirSom();
		
		girafa.exibirInfo();
		
        leao.exibirInfo();
		
		leao.metodoComer();
		
		leao.exibirInfo();
		
		leao.metodoEmitirSom();
		
		leao.exibirInfo();

	}

}


